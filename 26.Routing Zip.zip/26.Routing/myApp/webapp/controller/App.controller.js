sap.ui.define(['fiori/comp/syz/fa/controller/BaseController'],
    function(oBaseController){
        return oBaseController.extend('fiori.comp.syz.fa.controller.App',{
            onInit: function(){

            }
        });
    }
)